import React, { useEffect, useState } from 'react';
import Animate from './components/Animate';
import Notification from './components/Notification';
import Header from './components/Header';
import StatsGrid from './components/StatsGrid';
import Input from './components/Input';
import Todollist from './components/Todollist';
import Clearbutton from './components/Clearbutton';
import { playSound } from './components/PlaySound';

// const playSound = (data) => { };

const App = () => {


  const Storage_Key = "todos";
  const [todos, setTodos] = useState([])
  const [input, setInput] = useState("")
  const [notification, setNotification] = useState(null)
  const [editingId, setEditingId] = useState(null)
  const [editText, setEditText] = useState("")
  const [hasLoaded, setHasLoaded] = useState(false)

  // console.log("my todo", todos);



  //get from localstorage
  useEffect(() => {
    try {
      const data = localStorage.getItem(Storage_Key);
      if (data) {
        setTodos(JSON.parse(data));
      }
    } catch (error) {
      console.log("load error :", error);

    } finally {
      setHasLoaded(true);
    }

  }, [])


  // save to local storage

  useEffect(() => {
    if (!hasLoaded) return;
    try {
      localStorage.setItem(Storage_Key, JSON.stringify(todos));
    } catch (error) {
      console.log("save error :", error);

    }
  }, [todos, hasLoaded])

  // show notification 
  const showNotification = (message, type = "success") => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(null);
    }, 3000);
  }



  // add todo
  const handleAddtodo = () => {
    if (!input.trim()) return;

    const newTodo = {
      id: Date.now(),
      text: input,
      completed: false,
      createdAt: new Date().toISOString(),
    };

    setTodos([newTodo, ...todos]);
    setInput("")
    playSound("add");
    showNotification("✨ Task added successfully!");


  };

  // onToggle
  const toggleTodo = (id) => {
    setTodos(todos.map((todo) => (todo.id === id ? { ...todo, completed: !todo.completed } : todo
    )
    )
    );
    const todo = todos.find((t) => t.id === id)
    if (!todo.completed) {
      playSound("complete");
      showNotification("🎉 Great job! Task completed!");
    }

  };

  //key press down ( add )
  const handlekeydown = (e) => {
    if (e.key === "Enter") {
      handleAddtodo();
    }
  };

  // edit key press 
  const handleEditKeyPress = (e, id) => {
    if (e.key === "Enter") {
      saveEdit(id);
    } else if (e.key === "Escape") {
      cancelEdit();
    }
  }

  //start edit
  const startEdit = (id, text) => {
    //  console.log("editing started ", id, text);

    setEditingId(id);
    setEditText(text);
  };


  //update todo
  const saveEdit = (id) => {
    if (!editText.trim()) return;

    setTodos(todos.map((todo) => (todo.id === id ? { ...todo, text: editText } : todo)));
    setEditingId(null);
    setEditText("");
    playSound("update");
    showNotification("✏️ Task updated successfully!", "info");

  };

  // cancle editconst 
  const cancelEdit = () => {

    setEditText("");
    setEditingId(null);
  }




  // delete todo

  const deleteTodo = (id) => {
    setTodos(todos.filter((todos) => todos.id !== id));
    playSound("delete");
    showNotification("🗑️ Task deleted successfully!", "info");


  }


  // clear all completed task 
  const clearCompleted = () => {
    setTodos(todos.filter((t) => !t.completed));

    playSound("delete");
    showNotification("🗑️ All completed tasks cleared!", "info");
  }

  const activeTodos = todos.filter((t) => !t.completed).length;
  const completedTodos = todos.filter(t => t.completed).length;
  const progress = todos.length > 0 ? (completedTodos / todos.length) * 100 : 0;


  return (
    <>
      <div className="min-h-screen bg-linear-to-br from-indigo-950
       via-purple-950 to-pink-950 p-3 sm:p-6 relative overflow-hidden"
        style={{ minHeight: "100vh" }}>

        <Animate />

        <Notification notification={notification} onClose={() =>
          setNotification(null)} />
        <div className="max-w-3xl mx-auto relative z-10">


          <Header activeTodos={activeTodos} totalTodos={todos.length} progress={progress} />


          <StatsGrid activeTodos={activeTodos} totalTodos={todos.length} completedTodos={completedTodos} progress={progress} />


          <Input value={input}
            onChange={(e) => setInput(e.target.value)}
            onAdd={handleAddtodo}
            onKeyDown={handlekeydown}

          />
          <Todollist
            todos={todos}
            onDelete={deleteTodo}
            onStartEdit={startEdit}
            onSaveEdit={saveEdit}
            onCancelEdit={cancelEdit}
            editingId={editingId}
            editText={editText}
            onEditTextChange={(e) => setEditText(e.target.value)}
            onEditKeyPress={handleEditKeyPress}
            onToggle={toggleTodo}


          />
          <Clearbutton
            completedTodos={completedTodos}
            onClick={clearCompleted} />

        </div>


        <style>{`
        
        @Keyframes slideIn {
            from {
              opacity: 0;
              transform: translateY(20px);
            }
            to {
              opacity: 1;
              transform: translateY(0);
            }
          }
          @Keyframes float {
            0% ,100% { transform: translateY(0px) translateX(0px);}
            50% { transform: translateY(-20px) translateX(10px);}
          }
          @keyframes shimmer{
            0% { transform: translateX(-100%);}
            100% { transform: translateX(100%);}
          }
          .animate-shimmer {
            animation: shimmer 2s infinite;
            }
         `}
        </style>


      </div>
    </>
  )
}
export default App