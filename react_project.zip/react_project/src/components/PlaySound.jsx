const sounds = {
  add: '/sounds/add.mp3',
  complete: '/sounds/complete.mp3',
  delete: '/sounds/delete.mp3',
  update: '/sounds/update.mp3'
}

export const playSound = (type) => {
  const src = sounds[type];
  if (!src) return;

  const audio = new Audio(src);
  audio.volume = 0.6;
  audio.play().catch(() => {});
}
